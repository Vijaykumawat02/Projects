// Project Cyborg - AI-Powered Bug Bounty Assistant
class ProjectCyborg {
    constructor() {
        this.selectedScanType = null;
        this.currentUrl = '';
        this.isScanning = false;
        this.vulnerabilities = [];
        this.init();
    }

    init() {
        this.setupEventListeners();
        this.loadVulnerabilityData();
        this.updateAIStatus();
    }

    setupEventListeners() {
        // Navigation
        document.querySelectorAll('.nav-btn').forEach(btn => {
            btn.addEventListener('click', (e) => this.handleNavigation(e));
        });

        // URL input validation
        const urlInput = document.getElementById('target-url');
        urlInput.addEventListener('input', (e) => this.validateUrl(e.target.value));
        urlInput.addEventListener('blur', (e) => this.validateUrl(e.target.value));

        // Scan type selection
        document.querySelectorAll('.scan-type-card').forEach(card => {
            card.addEventListener('click', (e) => this.selectScanType(e));
        });

        // Start scan button
        document.getElementById('start-scan-btn').addEventListener('click', () => this.startScan());

        // Modal controls
        document.getElementById('close-modal').addEventListener('click', () => this.closeModal());
        document.getElementById('close-modal-btn').addEventListener('click', () => this.closeModal());
        document.getElementById('poc-modal').addEventListener('click', (e) => {
            if (e.target.id === 'poc-modal') this.closeModal();
        });

        // Download buttons
        document.getElementById('download-poc-btn').addEventListener('click', () => this.downloadPocReport());
        document.getElementById('download-report-btn').addEventListener('click', () => this.downloadFullReport());
    }

    handleNavigation(e) {
        const targetPage = e.target.dataset.page;
        
        // Update navigation state
        document.querySelectorAll('.nav-btn').forEach(btn => btn.classList.remove('active'));
        e.target.classList.add('active');

        // Show target page
        document.querySelectorAll('.page').forEach(page => page.classList.remove('active'));
        document.getElementById(`${targetPage}-page`).classList.add('active');
    }

    validateUrl(url) {
        const urlPattern = /^https?:\/\/(www\.)?[-a-zA-Z0-9@:%._\+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()@:%_\+.~#?&//=]*)$/;
        const validation = document.getElementById('url-validation');
        const startBtn = document.getElementById('start-scan-btn');

        if (url.length === 0) {
            validation.textContent = '';
            validation.className = 'url-validation';
            startBtn.disabled = true;
            this.currentUrl = '';
            return;
        }

        if (urlPattern.test(url)) {
            validation.textContent = '✓ Valid URL format';
            validation.className = 'url-validation valid';
            this.currentUrl = url;
            this.updateStartButton();
        } else {
            validation.textContent = '✗ Invalid URL format. Please enter a valid HTTP/HTTPS URL';
            validation.className = 'url-validation invalid';
            startBtn.disabled = true;
            this.currentUrl = '';
        }
    }

    selectScanType(e) {
        const card = e.currentTarget;
        const scanType = card.dataset.type;

        // Remove previous selection
        document.querySelectorAll('.scan-type-card').forEach(c => c.classList.remove('selected'));
        
        // Add selection to clicked card
        card.classList.add('selected');
        this.selectedScanType = scanType;
        this.updateStartButton();
    }

    updateStartButton() {
        const startBtn = document.getElementById('start-scan-btn');
        startBtn.disabled = !(this.currentUrl && this.selectedScanType && !this.isScanning);
    }

    async startScan() {
        if (!this.currentUrl || !this.selectedScanType || this.isScanning) return;

        this.isScanning = true;
        this.updateStartButton();

        // Hide results section if visible from previous scan
        document.getElementById('results-section').classList.add('hidden');

        // Show scanning progress immediately
        document.getElementById('scanning-progress').classList.remove('hidden');
        
        // Scroll to progress section
        document.getElementById('scanning-progress').scrollIntoView({ behavior: 'smooth' });

        // Start the scanning simulation
        await this.simulateScan();

        // Show results after scanning is complete
        this.displayResults();
        document.getElementById('scanning-progress').classList.add('hidden');
        document.getElementById('results-section').classList.remove('hidden');
        
        // Scroll to results
        document.getElementById('results-section').scrollIntoView({ behavior: 'smooth' });

        this.isScanning = false;
        this.updateStartButton();
    }

    async simulateScan() {
        const progressFill = document.querySelector('.progress-fill');
        const scanStatus = document.querySelector('.scan-status');
        
        const scanSteps = [
            { progress: 0, message: 'Initializing scan engine...' },
            { progress: 15, message: 'Analyzing target application...' },
            { progress: 30, message: 'Discovering endpoints and parameters...' },
            { progress: 45, message: 'Performing vulnerability discovery...' },
            { progress: 60, message: 'Running security tests...' },
            { progress: 75, message: 'Analyzing business logic...' },
            { progress: 90, message: 'Validating findings...' },
            { progress: 100, message: 'Generating comprehensive report...' }
        ];

        for (const step of scanSteps) {
            progressFill.style.width = `${step.progress}%`;
            scanStatus.textContent = step.message;
            
            // Add some visual feedback for the current step
            if (step.progress === 100) {
                scanStatus.textContent = '✓ Scan completed successfully!';
                scanStatus.style.color = 'var(--color-success)';
            }
            
            await this.delay(2000); // 2 seconds per step for more realistic timing
        }

        // Final delay to show completion message
        await this.delay(1000);
    }

    delay(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }

    displayResults() {
        // Filter vulnerabilities based on scan type
        let filteredVulns = this.getVulnerabilitiesForScanType(this.selectedScanType);
        
        // Update summary cards
        this.updateSummaryCards(filteredVulns);
        
        // Display vulnerability list
        this.displayVulnerabilityList(filteredVulns);
    }

    getVulnerabilitiesForScanType(scanType) {
        const allVulns = this.vulnerabilities;
        
        switch (scanType) {
            case 'quick':
                return allVulns.filter(v => ['SQL Injection', 'Stored Cross-Site Scripting (XSS)', 'Cross-Site Request Forgery (CSRF)', 'Missing Security Headers'].includes(v.name));
            case 'deep':
                return allVulns.filter(v => !v.name.includes('Business Logic'));
            case 'smart':
                return allVulns; // Smart scan finds all vulnerabilities
            default:
                return allVulns;
        }
    }

    updateSummaryCards(vulnerabilities) {
        const severityCounts = {
            critical: vulnerabilities.filter(v => v.severity === 'Critical').length,
            high: vulnerabilities.filter(v => v.severity === 'High').length,
            medium: vulnerabilities.filter(v => v.severity === 'Medium').length,
            low: vulnerabilities.filter(v => v.severity === 'Low').length
        };

        document.getElementById('total-vulns').textContent = vulnerabilities.length;
        document.getElementById('critical-count').textContent = severityCounts.critical;
        document.getElementById('high-count').textContent = severityCounts.high;
        document.getElementById('medium-count').textContent = severityCounts.medium;
        document.getElementById('low-count').textContent = severityCounts.low;

        // Calculate security score (100 - weighted vulnerability score)
        const weightedScore = (severityCounts.critical * 25) + (severityCounts.high * 15) + (severityCounts.medium * 8) + (severityCounts.low * 3);
        const securityScore = Math.max(0, 100 - weightedScore);
        document.getElementById('security-score').textContent = securityScore;
    }

    displayVulnerabilityList(vulnerabilities) {
        const container = document.getElementById('vulnerability-items');
        container.innerHTML = '';

        vulnerabilities.forEach(vuln => {
            const vulnElement = this.createVulnerabilityElement(vuln);
            container.appendChild(vulnElement);
        });
    }

    createVulnerabilityElement(vuln) {
        const element = document.createElement('div');
        element.className = 'vulnerability-item';
        
        element.innerHTML = `
            <div class="vulnerability-info">
                <h4>${vuln.name}</h4>
                <div class="vulnerability-meta">
                    <span class="vulnerability-url">${vuln.affected_url}</span>
                    <span class="coverage-tag">Parameter: ${vuln.parameter}</span>
                </div>
                <p class="vulnerability-description">${vuln.description}</p>
            </div>
            <div class="cvss-score">
                <span class="cvss-number severity-${vuln.severity.toLowerCase()}">${vuln.cvss_score}</span>
                <span class="severity-badge severity-${vuln.severity.toLowerCase()}">${vuln.severity}</span>
            </div>
            <button class="btn btn--primary btn--sm" onclick="cyborg.showPocModal('${vuln.id}')">
                View PoC
            </button>
        `;

        return element;
    }

    showPocModal(vulnId) {
        const vuln = this.vulnerabilities.find(v => v.id === vulnId);
        if (!vuln) return;

        // Populate modal content
        document.getElementById('poc-title').textContent = vuln.name;
        document.getElementById('poc-description').textContent = vuln.description;
        document.getElementById('poc-impact').textContent = vuln.impact;
        document.getElementById('poc-cvss-score').textContent = vuln.cvss_score;
        document.getElementById('poc-remediation').textContent = vuln.remediation;

        // Set CVSS score styling
        const cvssElement = document.getElementById('poc-cvss-score');
        cvssElement.className = `cvss-number severity-${vuln.severity.toLowerCase()}`;
        
        const severityElement = document.getElementById('poc-severity');
        severityElement.textContent = vuln.severity;
        severityElement.className = `severity-badge severity-${vuln.severity.toLowerCase()}`;

        // Populate reproduction steps
        const stepsContainer = document.getElementById('poc-steps');
        stepsContainer.innerHTML = '';
        vuln.reproduction_steps.forEach(step => {
            const li = document.createElement('li');
            li.textContent = step;
            stepsContainer.appendChild(li);
        });

        // Populate references
        const referencesContainer = document.getElementById('poc-references');
        referencesContainer.innerHTML = '';
        vuln.references.forEach(ref => {
            const li = document.createElement('li');
            li.textContent = ref;
            referencesContainer.appendChild(li);
        });

        // Store current vulnerability for download
        this.currentVuln = vuln;

        // Show modal
        document.getElementById('poc-modal').classList.remove('hidden');
        document.body.style.overflow = 'hidden';
    }

    closeModal() {
        document.getElementById('poc-modal').classList.add('hidden');
        document.body.style.overflow = '';
        this.currentVuln = null;
    }

    downloadPocReport() {
        if (!this.currentVuln) return;

        const reportContent = this.generatePocReportContent(this.currentVuln);
        this.downloadFile(`${this.currentVuln.name.replace(/[^a-z0-9]/gi, '_')}_PoC_Report.txt`, reportContent);
    }

    downloadFullReport() {
        const filteredVulns = this.getVulnerabilitiesForScanType(this.selectedScanType);
        const reportContent = this.generateFullReportContent(filteredVulns);
        this.downloadFile(`Cyborg_Security_Report_${new Date().toISOString().split('T')[0]}.txt`, reportContent);
    }

    generatePocReportContent(vuln) {
        return `
PROJECT CYBORG - VULNERABILITY REPORT
=====================================

Target: ${this.currentUrl}
Scan Date: ${new Date().toLocaleString()}
Scan Type: ${this.selectedScanType.charAt(0).toUpperCase() + this.selectedScanType.slice(1)} Scan

VULNERABILITY DETAILS
====================

Name: ${vuln.name}
Type: ${vuln.type}
Severity: ${vuln.severity}
CVSS Score: ${vuln.cvss_score}
Affected URL: ${vuln.affected_url}
Parameter: ${vuln.parameter}

DESCRIPTION
===========
${vuln.description}

IMPACT ASSESSMENT
=================
${vuln.impact}

STEPS TO REPRODUCE
==================
${vuln.reproduction_steps.map((step, index) => `${index + 1}. ${step}`).join('\n')}

REMEDIATION
===========
${vuln.remediation}

REFERENCES
==========
${vuln.references.join('\n')}

---
Report generated by Project Cyborg v1.0
AI-Powered Bug Bounty Assistant
        `.trim();
    }

    generateFullReportContent(vulnerabilities) {
        const severityCounts = {
            critical: vulnerabilities.filter(v => v.severity === 'Critical').length,
            high: vulnerabilities.filter(v => v.severity === 'High').length,
            medium: vulnerabilities.filter(v => v.severity === 'Medium').length,
            low: vulnerabilities.filter(v => v.severity === 'Low').length
        };

        const weightedScore = (severityCounts.critical * 25) + (severityCounts.high * 15) + (severityCounts.medium * 8) + (severityCounts.low * 3);
        const securityScore = Math.max(0, 100 - weightedScore);

        let report = `
PROJECT CYBORG - COMPREHENSIVE SECURITY REPORT
==============================================

Target: ${this.currentUrl}
Scan Date: ${new Date().toLocaleString()}
Scan Type: ${this.selectedScanType.charAt(0).toUpperCase() + this.selectedScanType.slice(1)} Scan

EXECUTIVE SUMMARY
=================
Total Vulnerabilities Found: ${vulnerabilities.length}
Security Score: ${securityScore}/100

Severity Breakdown:
- Critical: ${severityCounts.critical}
- High: ${severityCounts.high}
- Medium: ${severityCounts.medium}
- Low: ${severityCounts.low}

DETAILED FINDINGS
=================
`;

        vulnerabilities.forEach((vuln, index) => {
            report += `
${index + 1}. ${vuln.name}
${'='.repeat(vuln.name.length + 3)}
Severity: ${vuln.severity} (CVSS: ${vuln.cvss_score})
Location: ${vuln.affected_url}
Parameter: ${vuln.parameter}

Description: ${vuln.description}

Impact: ${vuln.impact}

Remediation: ${vuln.remediation}

References: ${vuln.references.join(', ')}
`;
        });

        report += `

RECOMMENDATIONS
===============
1. Address Critical and High severity vulnerabilities immediately
2. Implement a regular vulnerability assessment schedule
3. Follow secure coding practices as outlined in OWASP guidelines
4. Consider implementing a Web Application Firewall (WAF)
5. Regular security training for development teams

---
Report generated by Project Cyborg v1.0
AI-Powered Bug Bounty Assistant
`;

        return report.trim();
    }

    downloadFile(filename, content) {
        const blob = new Blob([content], { type: 'text/plain' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    }

    loadVulnerabilityData() {
        // Load vulnerability data from the provided JSON
        this.vulnerabilities = [
            {
                "id": "vuln_001",
                "name": "SQL Injection",
                "type": "Injection",
                "severity": "Critical",
                "cvss_score": 9.1,
                "affected_url": "/login.php",
                "parameter": "username",
                "description": "SQL injection vulnerability in login form allows database manipulation",
                "impact": "Complete database compromise, data theft, system takeover",
                "reproduction_steps": [
                    "Navigate to /login.php",
                    "Enter username: admin' OR '1'='1'-- ",
                    "Enter any password",
                    "Click login button",
                    "Observe successful authentication bypass"
                ],
                "remediation": "Use parameterized queries and input validation",
                "references": ["OWASP Top 10 A03", "PortSwigger SQL Injection"]
            },
            {
                "id": "vuln_002", 
                "name": "Stored Cross-Site Scripting (XSS)",
                "type": "XSS",
                "severity": "High",
                "cvss_score": 7.2,
                "affected_url": "/profile.php",
                "parameter": "bio",
                "description": "Stored XSS in user profile bio field",
                "impact": "Session hijacking, account takeover, malware distribution",
                "reproduction_steps": [
                    "Login to user account",
                    "Navigate to profile edit page",
                    "Enter payload in bio field: <script>alert('XSS')</script>",
                    "Save profile changes",
                    "View profile page to trigger stored XSS"
                ],
                "remediation": "Implement proper output encoding and CSP headers",
                "references": ["OWASP Top 10 A07", "PortSwigger XSS"]
            },
            {
                "id": "vuln_003",
                "name": "Cross-Site Request Forgery (CSRF)",
                "type": "CSRF", 
                "severity": "Medium",
                "cvss_score": 6.1,
                "affected_url": "/change-password.php",
                "parameter": "new_password",
                "description": "Missing CSRF protection on password change functionality",
                "impact": "Unauthorized password changes, account compromise",
                "reproduction_steps": [
                    "Create malicious HTML page with hidden form",
                    "Target authenticated user visits malicious page",
                    "Form auto-submits password change request",
                    "User's password is changed without consent"
                ],
                "remediation": "Implement CSRF tokens and SameSite cookie attributes",
                "references": ["OWASP Top 10 A01", "OWASP CSRF Prevention"]
            },
            {
                "id": "vuln_004",
                "name": "Missing Security Headers",
                "type": "Misconfiguration",
                "severity": "Low", 
                "cvss_score": 3.7,
                "affected_url": "Global",
                "parameter": "HTTP Headers",
                "description": "Critical security headers missing from HTTP responses",
                "impact": "Increased attack surface, clickjacking, MIME sniffing attacks",
                "reproduction_steps": [
                    "Send HTTP request to any page",
                    "Examine response headers",
                    "Note missing X-Frame-Options, X-Content-Type-Options",
                    "Verify missing Content-Security-Policy header"
                ],
                "remediation": "Configure web server to include security headers",
                "references": ["OWASP Secure Headers Project"]
            },
            {
                "id": "vuln_005",
                "name": "Business Logic Flaw - Payment Bypass",
                "type": "Business Logic",
                "severity": "High",
                "cvss_score": 8.3,
                "affected_url": "/checkout.php",
                "parameter": "total_amount",
                "description": "Price manipulation in checkout process allows payment bypass",
                "impact": "Financial loss, free product acquisition, revenue impact",
                "reproduction_steps": [
                    "Add items to shopping cart",
                    "Proceed to checkout page", 
                    "Intercept checkout request with proxy",
                    "Modify total_amount parameter to $0.01",
                    "Complete purchase with manipulated price"
                ],
                "remediation": "Implement server-side price validation and integrity checks",
                "references": ["OWASP Business Logic Flaws"]
            }
        ];
    }

    updateAIStatus() {
        // Update timestamps and status information
        const lastUpdateElement = document.querySelector('.status-item .status-value');
        if (lastUpdateElement) {
            lastUpdateElement.textContent = '2 hours ago';
        }
    }

    // Reset scanner for new scan
    resetScanner() {
        document.getElementById('results-section').classList.add('hidden');
        document.getElementById('scanning-progress').classList.add('hidden');
        
        // Reset progress bar
        const progressFill = document.querySelector('.progress-fill');
        const scanStatus = document.querySelector('.scan-status');
        progressFill.style.width = '0%';
        scanStatus.textContent = 'Initializing scan...';
        scanStatus.style.color = 'var(--color-text-secondary)';
        
        // Clear selections
        document.querySelectorAll('.scan-type-card').forEach(card => card.classList.remove('selected'));
        this.selectedScanType = null;
        document.getElementById('target-url').value = '';
        this.currentUrl = '';
        document.getElementById('url-validation').textContent = '';
        document.getElementById('url-validation').className = 'url-validation';
        
        this.updateStartButton();
        
        // Scroll back to top
        window.scrollTo({ top: 0, behavior: 'smooth' });
    }
}

// Initialize the application
const cyborg = new ProjectCyborg();

// Add keyboard shortcuts
document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
        cyborg.closeModal();
    }
});

// Add new scan button functionality
document.addEventListener('DOMContentLoaded', () => {
    // Add a new scan button to results section
    const resultsSection = document.getElementById('results-section');
    if (resultsSection) {
        const newScanBtn = document.createElement('button');
        newScanBtn.className = 'btn btn--outline mt-16';
        newScanBtn.textContent = 'Start New Scan';
        newScanBtn.onclick = () => cyborg.resetScanner();
        resultsSection.appendChild(newScanBtn);
    }
});

// Export for global access
window.cyborg = cyborg;